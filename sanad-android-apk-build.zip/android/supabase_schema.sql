-- =========================================================================
-- Sanad Educational Platform - Supabase PostgreSQL Database Schema
-- Run this script in the Supabase SQL Editor (https://app.supabase.com)
-- =========================================================================

-- 1. PROFILES TABLE (Linked with Supabase Auth)
CREATE TABLE IF NOT EXISTS public.profiles (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT,
    avatar_url TEXT,
    grade_track TEXT DEFAULT 'الصف الثالث الثانوي • شعبة علمي علوم',
    student_code TEXT DEFAULT 'SANAD-38291',
    is_subscribed BOOLEAN DEFAULT true,
    subscription_plan TEXT DEFAULT 'باقة المتفوق – الترم كامل 2025',
    streak_days INT DEFAULT 14,
    focus_hours INT DEFAULT 142,
    completed_lessons INT DEFAULT 134,
    total_lessons INT DEFAULT 160,
    accuracy_percent INT DEFAULT 88,
    exam_days_left INT DEFAULT 5,
    exam_subject TEXT DEFAULT 'الأحياء',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- 2. SUBJECTS / COURSES TABLE
CREATE TABLE IF NOT EXISTS public.subjects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- 'science-bio', 'science-math', 'literary', 'languages'
    teacher_name TEXT NOT NULL,
    lessons_count TEXT DEFAULT '34 درس ومسائل',
    progress_percent INT DEFAULT 0,
    next_lesson_title TEXT,
    icon_name TEXT DEFAULT 'menu_book',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Subjects are viewable by everyone" ON public.subjects FOR SELECT USING (true);
CREATE POLICY "Admins can insert/update subjects" ON public.subjects FOR ALL USING (auth.role() = 'service_role');

-- 3. LESSONS TABLE
CREATE TABLE IF NOT EXISTS public.lessons (
    id TEXT PRIMARY KEY,
    subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
    subject_title TEXT NOT NULL,
    chapter_title TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT,
    video_duration_text TEXT DEFAULT '32:45',
    current_position_text TEXT DEFAULT '00:00',
    progress_percent INT DEFAULT 0,
    focus_minutes_spent INT DEFAULT 0,
    is_completed BOOLEAN DEFAULT false,
    formula_header TEXT,
    formula_expression TEXT,
    formula_units TEXT,
    exam_tip TEXT,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Lessons are viewable by everyone" ON public.lessons FOR SELECT USING (true);

-- 4. NOTES & SUMMARIES TABLE
CREATE TABLE IF NOT EXISTS public.notes (
    id BIGSERIAL PRIMARY KEY,
    subject_id TEXT REFERENCES public.subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    subject TEXT NOT NULL,
    pages_count INT DEFAULT 16,
    size_mb NUMERIC(5, 2) DEFAULT 4.5,
    progress_percent INT DEFAULT 0,
    is_offline_ready BOOLEAN DEFAULT true,
    is_bookmarked BOOLEAN DEFAULT false,
    tag TEXT DEFAULT 'جاهز للطباعة',
    preview_image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Notes are viewable by everyone" ON public.notes FOR SELECT USING (true);

-- 5. STUDY TASKS TABLE
CREATE TABLE IF NOT EXISTS public.tasks (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    subtitle TEXT NOT NULL,
    is_completed BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tasks viewable by owner" ON public.tasks FOR SELECT USING (true);
CREATE POLICY "Tasks insertable by owner" ON public.tasks FOR INSERT WITH CHECK (true);
CREATE POLICY "Tasks updatable by owner" ON public.tasks FOR UPDATE USING (true);

-- 6. PAYMENT REQUESTS & SUBSCRIPTION CONFIRMATIONS
CREATE TABLE IF NOT EXISTS public.payment_requests (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    txn_code TEXT NOT NULL,
    amount_egp INT NOT NULL,
    payment_method TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    sender_phone TEXT NOT NULL,
    status TEXT DEFAULT 'pending_verification', -- 'pending_verification', 'approved', 'rejected'
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.payment_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Payment requests insertable by users" ON public.payment_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Payment requests viewable by users" ON public.payment_requests FOR SELECT USING (true);

-- =========================================================================
-- SEED INITIAL CURRICULUM DATA
-- =========================================================================

INSERT INTO public.subjects (id, name, category, teacher_name, lessons_count, progress_percent, next_lesson_title, icon_name, sort_order)
VALUES
    ('subj_physics', 'مادة الفيزياء للثانوية العامة', 'science-math,science-bio', 'أستاذ حسام خليل (كبير معلمي الفيزياء)', '34 درس ومسائل', 72, 'قانونا كيرشوف وتطبيقاتهما', 'electric_bolt', 1),
    ('subj_chemistry', 'الكيمياء العامة والعضوية', 'science-math,science-bio', 'د. نادية الشامي', '28 درس ومختبر', 85, 'تم الانتهاء من باب الاتزان الكيميائي', 'science', 2),
    ('subj_math', 'التفاضل والتكامل والجبر والهندسة', 'science-math', 'أ. أحمد سمير', '42 درس وتمارين مكثفة', 60, 'تطبيقات على القيم العظمى والصغرى', 'functions', 3),
    ('subj_bio', 'الأحياء والجيولوجيا', 'science-bio', 'د. محمد سامي', '30 درس ورسوم توضيحية', 45, 'فصل المناعة وآليات الدفاع', 'psychology', 4),
    ('subj_english', 'اللغة الإنجليزية العامة', 'languages,science-math,science-bio,literary', 'مستر كريم عبد العزيز', 'مستوى متقدم', 90, 'مكتمل تقريباً • مراجعة القصة والنصوص', 'translate', 5)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.lessons (id, subject_id, subject_title, chapter_title, title, description, formula_header, formula_expression, formula_units, exam_tip, sort_order)
VALUES
    ('les_ohm', 'subj_physics', 'الفيزياء الكهربية • الثانوية العامة', 'الفصل الأول - الفيزياء الكهربية', 'الدرس الثالث: قانون أوم للدوائر المغلقة', 'استنتاج العلاقة الرياضية بين القوة الدافعة الكهربية وفرق الجهد الخارجي، وتأثير المقاومة الداخلية للمصدر.', 'شدة التيار الكهربي الكلي في الدائرة المغلقة', 'I = VB / (R + r)', 'أمبير (A) = فولت (V) ÷ أوم (Ω)', 'قراءة الفولتميتر بين قطبي البطارية: V = VB - Ir. لاحظ أن العلاقة بين فرق الجهد (V) وشدة التيار (I) هي علاقة تناقصية، وميل الخط المستقيم يمثل السالب للمقاومة الداخلية (-r)، والجزء المقطوع من محور الصادات يساوي VB.', 1)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.notes (id, subject_id, title, author, subject, pages_count, size_mb, progress_percent, is_offline_ready, is_bookmarked, tag)
VALUES
    (1, 'subj_physics', 'مذكرة القمة في الفيزياء الكهربية - الباب الأول', 'مستر حسام خليل • شرح تفصيلي وتطبيقات قانون كيرشوف وأوم للدائرة المغلقة', 'فيزياء 3 ث', 48, 6.2, 100, true, true, 'جاهز للطباعة'),
    (2, 'subj_chemistry', 'خرائط المفاهيم الذكية في الكيمياء العضوية', 'د. نادية الشامي • مخططات ربط تفاعلات الألكانات والألكينات ومشتقات الهيدروكربونات', 'كيمياء عامة', 24, 8.4, 45, true, false, 'ملون للطباعة'),
    (3, 'subj_math', 'ملخص القوانين والعلاقات الرياضية في التفاضل والتكامل', 'أ. أحمد سمير • اشتقاقات الدوال المثلثية، المساحات والحجوم، ومسائل المعدلات الزمنية', 'رياضيات بحتة', 16, 2.8, 0, true, false, 'جاهز للطباعة'),
    (4, 'subj_bio', 'المعسكر النهائي في علم الأحياء والجيولوجيا (DNA والتكاثر)', 'د. محمد سامي • تلخيص رسومات الأحياء المقررة ومقارنات الهندسة الوراثية', 'أحياء وجيولوجيا', 36, 5.1, 80, false, true, 'مراجعة نهائية'),
    (5, 'subj_english', 'توقعات ليلة الامتحان في اللغة الإنجليزية وقواعد القصة', 'مستر كريم عبد العزيز • أهم الكلمات المترادفة، الأزمنة المركبة، وأسئلة التفكير النقدي', 'اللغة الإنجليزية', 28, 3.9, 90, false, false, 'جاهز للطباعة')
ON CONFLICT (id) DO NOTHING;
