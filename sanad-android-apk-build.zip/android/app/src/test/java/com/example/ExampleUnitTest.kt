package com.example

import com.example.data.model.BillingPeriod
import com.example.data.model.User
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun userDefaultValues_areCorrect() {
        val user = User(id = "usr_1", name = "طالب مسجل", email = "student@test.com")
        assertEquals("usr_1", user.id)
        assertEquals("طالب مسجل", user.name)
        assertEquals("student@test.com", user.email)
        assertFalse(user.isSubscribed)
    }

    @Test
    fun billingPeriods_containExpectedValues() {
        assertEquals("شهري", BillingPeriod.MONTHLY.title)
        assertEquals("ترم كامل", BillingPeriod.TERM.title)
        assertEquals("السنة كاملة", BillingPeriod.YEAR.title)
    }
}
