package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Coursera / Uber / Edraak Modern Tech Palette:
// Primary: Deep Modern Electric Blue (Coursera / Tech Academy signature)
val CourseraBlue = Color(0xFF0056D2)
val CourseraBlueDark = Color(0xFF00419E)
val CourseraBlueLight = Color(0xFFEBF3FF)

// Uber / inDrive Crisp Accents:
val UberBlack = Color(0xFF000000)
val UberDarkSurface = Color(0xFF121212)
val InDriveLime = Color(0xFF99E600) // Vibrant inDrive high-energy accent
val ModernEmerald = Color(0xFF00B074) // Edraak / Success green

// Clean Modern Surface Hierarchy:
val SurfacePureWhite = Color(0xFFFFFFFF)
val SurfaceGray50 = Color(0xFFF8F9FA)
val SurfaceGray100 = Color(0xFFF1F3F5)
val SurfaceGray200 = Color(0xFFE9ECEF)
val SurfaceGray300 = Color(0xFFDEE2E6)

// Text tokens:
val TextPrimary = Color(0xFF1E2124)
val TextSecondary = Color(0xFF5A6578)
val TextMuted = Color(0xFF868E96)
val BorderSubtle = Color(0xFFE9ECEF)

// Legacy aliases mapped smoothly to new high-end look:
val DeepTeal = CourseraBlue
val DeepTealContainer = CourseraBlueDark
val TealAccent = CourseraBlue
val OnTealContainer = Color(0xFFD4E5FF)

val SageGreen = ModernEmerald
val SageGreenContainer = Color(0xFFE6F7F0)
val OnSageContainer = Color(0xFF006642)
val SageFixed = Color(0xFFCEF4E4)

val AmberWarm = Color(0xFFFF9500)
val AmberWarmContainer = Color(0xFFFFF3E0)
val AmberFixed = Color(0xFFFFE0B2)
val AmberFixedDim = Color(0xFFFFB74D)
val OnAmberFixed = Color(0xFFE65100)

val SurfacePaper = SurfaceGray50
val SurfaceContainerLowest = SurfacePureWhite
val SurfaceContainerLow = SurfaceGray50
val SurfaceContainer = SurfaceGray100
val SurfaceContainerHigh = SurfaceGray200
val SurfaceContainerHighest = SurfaceGray300

val OnSurfaceCharcoal = TextPrimary
val OnSurfaceVariant = TextSecondary
val OutlineGrey = TextMuted
val OutlineVariant = BorderSubtle

val ErrorRed = Color(0xFFFA5252)
val ErrorContainer = Color(0xFFFFE3E3)
val OnError = SurfacePureWhite
