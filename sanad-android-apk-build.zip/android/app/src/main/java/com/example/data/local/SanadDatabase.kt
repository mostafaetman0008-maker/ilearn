package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [StudyTaskEntity::class, NoteItemEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SanadDatabase : RoomDatabase() {
    abstract fun taskDao(): StudyTaskDao
    abstract fun noteDao(): StudyNoteDao

    companion object {
        @Volatile
        private var INSTANCE: SanadDatabase? = null

        fun getDatabase(context: Context): SanadDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SanadDatabase::class.java,
                    "sanad_study_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
