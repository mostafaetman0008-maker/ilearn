package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.User
import com.example.ui.theme.AmberFixed
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.DeepTeal
import com.example.ui.theme.DeepTealContainer
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.OnAmberFixed
import com.example.ui.theme.OutlineVariant
import com.example.ui.theme.SageFixed
import com.example.ui.theme.SageGreen
import com.example.ui.theme.SageGreenContainer
import com.example.ui.theme.SurfaceContainer
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.SurfacePaper

@Composable
fun ProfileScreen(
    user: User,
    supabaseSyncStatus: String,
    supabaseUrl: String = "",
    supabaseAnonKey: String = "",
    isComfortMode: Boolean,
    onToggleComfortMode: () -> Unit,
    onCopyCode: (String) -> Unit,
    onRenewSubscription: () -> Unit,
    onUpdateSupabaseCredentials: (String, String) -> Unit = { _, _ -> },
    onTestSupabaseConnection: ((Boolean, String) -> Unit) -> Unit = {},
    onCopySqlSchema: () -> Unit = {},
    onSyncNow: () -> Unit = {},
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showSupabaseConfigDialog by remember { mutableStateOf(false) }
    var inputUrl by remember { mutableStateOf(supabaseUrl) }
    var inputKey by remember { mutableStateOf(supabaseAnonKey) }
    var testResultText by remember { mutableStateOf<String?>(null) }
    var isTestingConnection by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfacePaper)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // 1. Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(1.dp, RoundedCornerShape(20.dp))
                    .testTag("profile_header_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Avatar with Halo
                    Box(modifier = Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(SageGreenContainer.copy(alpha = 0.5f))
                        )
                        AsyncImage(
                            model = user.avatarUrl,
                            contentDescription = "Avatar",
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(DeepTeal),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "موثق",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Text(
                        text = user.name,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepTeal
                    )

                    Text(
                        text = user.gradeTrack,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Subscription Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(AmberFixed.copy(alpha = 0.7f))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = AmberWarm,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = user.subscriptionPlan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = OnAmberFixed
                            )
                        }
                    }

                    // Gentle Affirmation
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceContainerLow)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Spa,
                                contentDescription = null,
                                tint = SageGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Text("جلسة اليوم: بالراحة وخطوة خطوة", fontSize = 11.sp, color = SageGreen)
                        }
                        Text("متبقي 62 يوماً للاختبارات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // 2. Focus Stats Bento Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Insights,
                            contentDescription = null,
                            tint = DeepTeal,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("إحصائيات التعلم والمسار الأكاديمي", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                    }
                    Text("محدّثة اليوم", fontSize = 11.sp, color = SageGreen)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Hours
                    StatCard(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.Timer,
                        iconBg = SageGreenContainer.copy(alpha = 0.6f),
                        iconTint = SageGreen,
                        badge = "+18% هذا الشهر",
                        value = "${user.focusHours}",
                        label = "إجمالي ساعات التركيز"
                    )

                    // Streak
                    StatCard(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.LocalFireDepartment,
                        iconBg = AmberFixed.copy(alpha = 0.7f),
                        iconTint = AmberWarm,
                        badge = "مستمر بقوة",
                        value = "${user.streakDays}",
                        unit = "يوماً",
                        label = "تتابع الأيام المستمر"
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Lessons
                    StatCard(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.MenuBook,
                        iconBg = SageGreenContainer.copy(alpha = 0.6f),
                        iconTint = SageGreen,
                        badge = "من 160 درس",
                        value = "${user.completedLessons}",
                        label = "درساً مكتملاً ومراجعاً"
                    )

                    // Accuracy
                    StatCard(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.TaskAlt,
                        iconBg = DeepTeal.copy(alpha = 0.15f),
                        iconTint = DeepTeal,
                        badge = "بابل شيت",
                        value = "${user.accuracyPercent}%",
                        label = "متوسط نسبة الدقة"
                    )
                }
            }
        }

        // 3. Subscription & Student Account Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DeepTealContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(2.dp, RoundedCornerShape(16.dp))
                    .testTag("profile_student_code_card")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "كود الطالب الأكاديمي",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = user.studentCode,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                IconButton(
                                    onClick = { onCopyCode(user.studentCode) },
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "نسخ الكود",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = SageFixed,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // Payment Gateway Pills
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الدفع المباشر: فودافون كاش • إنستاباي",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                            Text(
                                text = "فوري متاح",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SageFixed
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onRenewSubscription,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(42.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SurfaceContainerLowest,
                                contentColor = DeepTeal
                            )
                        ) {
                            Text("تجديد / ترقية الباقة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onRenewSubscription,
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.15f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("الفواتير", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 4. Academic Badges
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MilitaryTech,
                            contentDescription = null,
                            tint = DeepTeal,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("الأوسمة والشارات الأكاديمية", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                    }
                    Text("عرض الكل (8)", fontSize = 11.sp, color = SageGreen)
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        BadgeCard(
                            title = "سفير الانضباط",
                            desc = "10 أيام دراسة متتالية دون انقطاع",
                            tag = "مكتمل 100%",
                            icon = Icons.Default.VerifiedUser,
                            iconTint = SageGreen
                        )
                    }
                    item {
                        BadgeCard(
                            title = "بطل الفيزياء",
                            desc = "حل 5 اختبارات بابل شيت بامتياز",
                            tag = "امتياز 95%",
                            icon = Icons.Default.Psychology,
                            iconTint = AmberWarm
                        )
                    }
                    item {
                        BadgeCard(
                            title = "مذاكرة الفجر",
                            desc = "تركيز صباحي مبكر لصفاء الذهن",
                            tag = "نشط هذا الأسبوع",
                            icon = Icons.Default.WbTwilight,
                            iconTint = DeepTeal
                        )
                    }
                }
            }
        }

        // 5. Notebook-Style Quick Settings
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.StickyNote2,
                        contentDescription = null,
                        tint = DeepTeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Text("دفتر التحكم والإعدادات السريعة", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(1.dp, RoundedCornerShape(16.dp))
                ) {
                    Column {
                        SettingItem(
                            icon = Icons.Default.Schedule,
                            title = "جدول المذاكرة والتنبيهات",
                            desc = "تنظيم فترات التركيز وراحة العين",
                            badge = "منظم",
                            onClick = {}
                        )

                        SettingItem(
                            icon = Icons.Default.Bookmark,
                            title = "المذكرات المحفوظة والمفضلة",
                            desc = "ملخصات الكيمياء والجيولوجيا والمراجعات",
                            badge = "24 ملخص",
                            onClick = {}
                        )

                        SettingItem(
                            icon = Icons.Default.SupportAgent,
                            title = "حجز استشارة تعليمية",
                            desc = "جلسة 20 دقيقة مع مرشد أكاديمي متخصص",
                            badge = "جلسة مجانية",
                            onClick = {}
                        )

                        SettingItem(
                            icon = Icons.Default.Chat,
                            title = "الدعم الفني والمالي المباشر",
                            desc = "محادثة واتساب • تأكيد تحويلات كاش وإنستاباي",
                            badge = "متصل الآن",
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/201023456789"))
                                context.startActivity(intent)
                            }
                        )

                        // Eye Comfort Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(SurfaceContainerLow),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Visibility,
                                        contentDescription = null,
                                        tint = DeepTeal,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text("المظهر المريح للعين", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                    Text("إضاءة دافئة وخط عريض لتقليل الإجهاد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Switch(
                                checked = isComfortMode,
                                onCheckedChange = { onToggleComfortMode() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = SageGreen
                                )
                            )
                        }

                        // Supabase cloud sync status & config
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    inputUrl = supabaseUrl
                                    inputKey = supabaseAnonKey
                                    testResultText = null
                                    showSupabaseConfigDialog = true
                                }
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(SageGreenContainer.copy(alpha = 0.5f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudSync,
                                        contentDescription = null,
                                        tint = DeepTeal,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text("ربط قاعدة بيانات Supabase (لوحة التحكم)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                    Text(supabaseSyncStatus.ifBlank { "اضغط لتعديل الرابط واختبار الاتصال" }, fontSize = 11.sp, color = SageGreen)
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                tint = DeepTeal,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Copy SQL Schema action
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onCopySqlSchema() }
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(SurfaceContainerLow),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = null,
                                        tint = DeepTeal,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text("نسخ كود جداول SQL لقاعدة البيانات", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                    Text("لتشغيله في Supabase SQL Editor لمطابقة الويب والموبايل", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        // Logout button
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onLogout() }
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(ErrorContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Logout,
                                        contentDescription = null,
                                        tint = ErrorRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text("تسجيل الخروج", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
                                    Text("تسجيل الخروج من الحساب الأكاديمي", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                tint = ErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Reassuring Note Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("منصة iLearn • سند التعليمية لطلاب الثانوية العامة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(2.dp))
                Text("تذكر دائماً: خطوة واحدة واثقة كل يوم تصنع الفارق الكبير 🌱", fontSize = 11.sp, color = SageGreen)
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showSupabaseConfigDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSupabaseConfigDialog = false },
            title = {
                Text(
                    text = "ربط وتطابق قاعدة بيانات Supabase",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepTeal
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "أدخل بيانات مشروع Supabase لربط تطبيق الموبايل مع لوحة تحكم موقع الويب في نفس قاعدة البيانات:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it },
                        label = { Text("Project URL (عنوان الرابط)") },
                        placeholder = { Text("https://xyz.supabase.co") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = inputKey,
                        onValueChange = { inputKey = it },
                        label = { Text("Anon Public Key (المفتاح العام)") },
                        placeholder = { Text("eyJhbGciOi...") },
                        singleLine = false,
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    val curResult = testResultText
                    if (curResult != null) {
                        Text(
                            text = curResult,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (curResult.startsWith("✓")) SageGreen else ErrorRed
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                isTestingConnection = true
                                testResultText = "جاري اختبار الاتصال..."
                                onUpdateSupabaseCredentials(inputUrl, inputKey)
                                onTestSupabaseConnection { success, message ->
                                    isTestingConnection = false
                                    testResultText = if (success) "✓ $message" else "✗ $message"
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceContainerHigh, contentColor = DeepTeal)
                        ) {
                            Text("اختبار الاتصال", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onSyncNow()
                                testResultText = "✓ جاري سحب البيانات ومزامنتها الآن..."
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceContainerHigh, contentColor = DeepTeal)
                        ) {
                            Text("مزامنة فورية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateSupabaseCredentials(inputUrl, inputKey)
                        showSupabaseConfigDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepTeal)
                ) {
                    Text("حفظ والاتصال")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSupabaseConfigDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    iconTint: Color,
    badge: String,
    value: String,
    unit: String = "",
    label: String
) {
    Card(
        modifier = modifier.shadow(1.dp, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(16.dp))
                }
                Text(badge, fontSize = 10.sp, color = iconTint, fontWeight = FontWeight.Bold)
            }

            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                if (unit.isNotBlank()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(unit, fontSize = 12.sp, color = iconTint, fontWeight = FontWeight.SemiBold)
                }
            }

            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BadgeCard(
    title: String,
    desc: String,
    tag: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
        modifier = Modifier
            .width(170.dp)
            .shadow(1.dp, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SurfaceContainerLow),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
            Text(desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceContainerLow)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(tag, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SageGreen)
            }
        }
    }
}

@Composable
private fun SettingItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    badge: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceContainerLow),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = SageGreen, modifier = Modifier.size(18.dp))
            }
            Column {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                Text(desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(SageGreenContainer.copy(alpha = 0.5f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SageGreen)
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
