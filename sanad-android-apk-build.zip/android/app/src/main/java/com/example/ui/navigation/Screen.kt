package com.example.ui.navigation

enum class Screen {
    LOGIN,
    DASHBOARD,
    CURRICULUM,
    LESSON_DETAIL,
    QUIZ,
    LIBRARY,
    PROFILE,
    SUBSCRIPTION,
    CONFIRMATION
}
