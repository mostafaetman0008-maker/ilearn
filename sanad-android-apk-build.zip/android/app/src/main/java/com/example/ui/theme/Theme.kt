package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = DeepTeal,
    onPrimary = Color.White,
    primaryContainer = DeepTealContainer,
    onPrimaryContainer = OnTealContainer,
    secondary = SageGreen,
    onSecondary = Color.White,
    secondaryContainer = SageGreenContainer,
    onSecondaryContainer = OnSageContainer,
    tertiary = AmberWarm,
    onTertiary = Color.White,
    tertiaryContainer = AmberWarmContainer,
    onTertiaryContainer = AmberFixedDim,
    background = SurfacePaper,
    onBackground = OnSurfaceCharcoal,
    surface = SurfacePaper,
    onSurface = OnSurfaceCharcoal,
    surfaceVariant = SurfaceContainerHighest,
    onSurfaceVariant = OnSurfaceVariant,
    surfaceContainerLowest = SurfaceContainerLowest,
    surfaceContainerLow = SurfaceContainerLow,
    surfaceContainer = SurfaceContainer,
    surfaceContainerHigh = SurfaceContainerHigh,
    surfaceContainerHighest = SurfaceContainerHighest,
    outline = OutlineGrey,
    outlineVariant = OutlineVariant,
    error = ErrorRed,
    errorContainer = ErrorContainer,
    onError = OnError
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF9FCFD1),
    onPrimary = Color(0xFF003638),
    primaryContainer = Color(0xFF1B4D4F),
    onPrimaryContainer = Color(0xFFBAECED),
    secondary = Color(0xFFA6CFC3),
    onSecondary = Color(0xFF00201A),
    secondaryContainer = Color(0xFF274E45),
    onSecondaryContainer = Color(0xFFC1EBDF),
    tertiary = Color(0xFFFABA75),
    onTertiary = Color(0xFF2B1700),
    background = Color(0xFF1A1C1A),
    onBackground = Color(0xFFF2F1EE),
    surface = Color(0xFF1E201E),
    onSurface = Color(0xFFF2F1EE),
    surfaceVariant = Color(0xFF2F312F),
    onSurfaceVariant = Color(0xFFC0C8C8)
)

@Composable
fun SanadTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
