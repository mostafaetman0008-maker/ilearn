package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_tasks")
data class StudyTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subtitle: String,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_notes")
data class NoteItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String,
    val subject: String,
    val pagesCount: Int,
    val sizeMb: Double,
    val progressPercent: Int,
    val isOfflineReady: Boolean,
    val isBookmarked: Boolean,
    val tag: String,
    val previewImageUrl: String = ""
)
