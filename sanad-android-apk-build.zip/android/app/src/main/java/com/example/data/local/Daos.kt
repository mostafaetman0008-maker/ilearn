package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY id ASC")
    fun getAllTasks(): Flow<List<StudyTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<StudyTaskEntity>)

    @Update
    suspend fun updateTask(task: StudyTaskEntity)

    @Query("UPDATE study_tasks SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun setTaskCompleted(id: Long, isCompleted: Boolean)

    @Query("SELECT COUNT(*) FROM study_tasks")
    suspend fun getTaskCount(): Int
}

@Dao
interface StudyNoteDao {
    @Query("SELECT * FROM study_notes ORDER BY id ASC")
    fun getAllNotes(): Flow<List<NoteItemEntity>>

    @Query("SELECT * FROM study_notes WHERE isOfflineReady = 1")
    fun getOfflineNotes(): Flow<List<NoteItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<NoteItemEntity>)

    @Update
    suspend fun updateNote(note: NoteItemEntity)

    @Query("UPDATE study_notes SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun setBookmark(id: Long, isBookmarked: Boolean)

    @Query("UPDATE study_notes SET isOfflineReady = :isOffline WHERE id = :id")
    suspend fun setOfflineReady(id: Long, isOffline: Boolean)

    @Query("SELECT COUNT(*) FROM study_notes")
    suspend fun getNoteCount(): Int
}
