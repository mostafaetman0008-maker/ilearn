package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.NoteItemEntity
import com.example.data.local.SanadDatabase
import com.example.data.local.StudyTaskEntity
import com.example.data.model.Lesson
import com.example.data.model.LessonAttachment
import com.example.data.model.NoteItem
import com.example.data.model.PaymentReceipt
import com.example.data.model.QuizOption
import com.example.data.model.QuizQuestion
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.User
import com.example.data.remote.SupabaseManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

class SanadRepository(
    private val database: SanadDatabase,
    context: Context? = null
) {
    companion object {
        private const val TAG = "SanadRepository"
    }

    val supabaseManager: SupabaseManager = SupabaseManager(context)

    private val taskDao = database.taskDao()
    private val noteDao = database.noteDao()

    private val _subjects = MutableStateFlow<List<Subject>>(emptyList())
    val subjects: StateFlow<List<Subject>> = _subjects.asStateFlow()

    val allTasks: Flow<List<StudyTask>> = taskDao.getAllTasks().map { entities ->
        entities.map {
            StudyTask(
                id = it.id,
                title = it.title,
                subtitle = it.subtitle,
                isCompleted = it.isCompleted
            )
        }
    }

    val allNotes: Flow<List<NoteItem>> = noteDao.getAllNotes().map { entities ->
        entities.map {
            NoteItem(
                id = it.id,
                title = it.title,
                author = it.author,
                subject = it.subject,
                pagesCount = it.pagesCount,
                sizeMb = it.sizeMb,
                progressPercent = it.progressPercent,
                isOfflineReady = it.isOfflineReady,
                isBookmarked = it.isBookmarked,
                tag = it.tag,
                previewImageUrl = it.previewImageUrl
            )
        }
    }

    suspend fun initializeDefaultDataIfEmpty() {
        if (_subjects.value.isEmpty()) {
            _subjects.value = getCurriculumSubjects()
        }

        if (noteDao.getNoteCount() == 0) {
            val initialNotes = listOf(
                NoteItemEntity(
                    title = "مذكرة الفيزياء الكهربية - الباب الأول",
                    author = "أ. حسام خليل • شرح تفصيلي وتطبيقات قانون كيرشوف وأوم",
                    subject = "فيزياء للثانوية العامة",
                    pagesCount = 48,
                    sizeMb = 6.2,
                    progressPercent = 100,
                    isOfflineReady = true,
                    isBookmarked = true,
                    tag = "مذكرة معتمدة",
                    previewImageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAcBUcCCAHiQJ7JEOJH6iWrG54waSPHR4mQDb8QRFs3sGn8Yudgkqfk6oSgF51O_h5Xj8jo_gS26WvyqS0ciO5cI8vTt5O7206Rlv1B_Odvvzj9YIxUYUBut6vZhii-dwqydA-CDcPWOs1To2bMvzYtle_AKDeJZsw_7C4vswgk7aSrkkX1c_r6UJ9N0WofR0WbHdg2yp3JhApAUnMXerBVO7uWX4R_MQByYcOiCrFq6d8bcJH_MYnJ"
                ),
                NoteItemEntity(
                    title = "خرائط المفاهيم في الكيمياء العضوية",
                    author = "د. نادية الشامي • مخططات ربط تفاعلات الألكانات والألكينات",
                    subject = "كيمياء عامة",
                    pagesCount = 24,
                    sizeMb = 8.4,
                    progressPercent = 45,
                    isOfflineReady = true,
                    isBookmarked = false,
                    tag = "ملخص دراسي",
                    previewImageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCClXu-KAnfb0agdDXi-e5MGAUeXAIjQR9nZtrzS9MYI6djHbuq4qktriH9b13g51pl9r60G6B_nFT9ISr5FrsB8YTNqmQqb9c2LpMMgvrPll548qf-mHXOigiCzeLdGv2fdLfDmTTnasa9iYENjmrGupPJdV3tJmnGpB9IU4SxbxZjYdbn-cQEfRCnJ_lzddJ20FuEynwO8X0WSlCf3HjNCXt7mcARyDx05vKbpRCxJbzViCBai0xh"
                ),
                NoteItemEntity(
                    title = "ملخص القوانين والعلاقات الرياضية في التفاضل والتكامل",
                    author = "أ. أحمد سمير • اشتقاقات الدوال المثلثية ومسائل المعدلات الزمنية",
                    subject = "رياضيات",
                    pagesCount = 16,
                    sizeMb = 2.8,
                    progressPercent = 0,
                    isOfflineReady = true,
                    isBookmarked = false,
                    tag = "قوانين مختصرة"
                ),
                NoteItemEntity(
                    title = "ملخص علم الأحياء والوراثة (DNA والتكاثر)",
                    author = "د. محمد سامي • تلخيص رسومات الأحياء المقررة ومقارنات الوراثة",
                    subject = "أحياء وجيولوجيا",
                    pagesCount = 36,
                    sizeMb = 5.1,
                    progressPercent = 80,
                    isOfflineReady = false,
                    isBookmarked = true,
                    tag = "مراجعة نهائية",
                    previewImageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAxj9r0TmynZ-DxVT9Qa4fq6xrY6XcC41lNLYHazteq61zz9JT1u0Cnmq9egGTxZmBnDpw839v52KaOvnJIsrB3dt6x2PO6cV7f_GAXB_D83GFB8vH3N04080xXyDpEoLGhYyAxWbuD-3vVY4E7kXgIrssUi9elseSHrvMfuKCgUCvYFEh9Z7-hlkCFY4pG3gdfaU2K1JZ9HwfIZ6Z6YDxzYBM6y978V9OJefc_DsV1bvPAjgtoTe6c"
                )
            )
            noteDao.insertNotes(initialNotes)
        }

        if (taskDao.getTaskCount() == 0) {
            val initialTasks = listOf(
                StudyTaskEntity(
                    title = "حل 10 أسئلة بنك المعرفة في الكيمياء",
                    subtitle = "الكيمياء العضوية • الهيدروكربونات",
                    isCompleted = false
                ),
                StudyTaskEntity(
                    title = "مراجعة الباب الثاني أحياء",
                    subtitle = "التركيب والوظيفة • التنسيق الهرموني",
                    isCompleted = true
                )
            )
            taskDao.insertTasks(initialTasks)
        }
    }

    // Two-way synchronization with Supabase Database (Web Dashboard <-> Mobile)
    suspend fun syncWithSupabase(userId: String): Boolean {
        var anySyncSuccess = false

        // 1. Fetch Subjects / Courses from Supabase
        val subjectsResult = supabaseManager.fetchSubjects()
        if (subjectsResult.isSuccess && subjectsResult.getOrNull()?.isNotEmpty() == true) {
            _subjects.value = subjectsResult.getOrNull()!!
            anySyncSuccess = true
            Log.d(TAG, "Synced ${subjectsResult.getOrNull()?.size} courses/subjects from Supabase")
        }

        // 2. Fetch Notes from Supabase
        val notesResult = supabaseManager.fetchNotes()
        if (notesResult.isSuccess && notesResult.getOrNull()?.isNotEmpty() == true) {
            val entities = notesResult.getOrNull()!!.map {
                NoteItemEntity(
                    id = it.id,
                    title = it.title,
                    author = it.author,
                    subject = it.subject,
                    pagesCount = it.pagesCount,
                    sizeMb = it.sizeMb,
                    progressPercent = it.progressPercent,
                    isOfflineReady = it.isOfflineReady,
                    isBookmarked = it.isBookmarked,
                    tag = it.tag,
                    previewImageUrl = it.previewImageUrl
                )
            }
            noteDao.insertNotes(entities)
            anySyncSuccess = true
            Log.d(TAG, "Synced ${entities.size} notes from Supabase into local Room database")
        }

        // 3. Fetch Tasks from Supabase
        val tasksResult = supabaseManager.fetchTasks(userId)
        if (tasksResult.isSuccess && tasksResult.getOrNull()?.isNotEmpty() == true) {
            val entities = tasksResult.getOrNull()!!.map {
                StudyTaskEntity(
                    id = it.id,
                    title = it.title,
                    subtitle = it.subtitle,
                    isCompleted = it.isCompleted
                )
            }
            taskDao.insertTasks(entities)
            anySyncSuccess = true
            Log.d(TAG, "Synced ${entities.size} tasks from Supabase into local Room database")
        }

        return anySyncSuccess
    }

    suspend fun toggleTask(userId: String, id: Long, completed: Boolean) {
        taskDao.setTaskCompleted(id, completed)
        supabaseManager.updateTaskStatus(id, completed)
    }

    suspend fun addNewTask(userId: String, title: String, subtitle: String) {
        val insertedId = taskDao.insertTask(
            StudyTaskEntity(
                title = title,
                subtitle = subtitle,
                isCompleted = false
            )
        )
        supabaseManager.createTask(userId, title, subtitle)
    }

    suspend fun toggleBookmark(id: Long, current: Boolean) {
        noteDao.setBookmark(id, !current)
    }

    suspend fun toggleOfflineReady(id: Long, current: Boolean) {
        noteDao.setOfflineReady(id, !current)
    }

    suspend fun submitPaymentRequest(userId: String, receipt: PaymentReceipt) {
        supabaseManager.submitPaymentRequest(userId, receipt)
    }

    fun getCurriculumSubjects(): List<Subject> = listOf(
        Subject(
            id = "subj_physics",
            name = "الفيزياء للثانوية العامة",
            category = "science-math,science-bio",
            teacherName = "أ. حسام خليل",
            lessonsCount = "34 درس وتطبيقات",
            progressPercent = 72,
            nextLessonTitle = "قانونا كيرشوف وتطبيقاتهما",
            iconName = "electric_bolt",
            description = "شرح وافٍ لمنهج الفيزياء وتطبيقات حل المسائل وبنك أسئلة الامتحانات"
        ),
        Subject(
            id = "subj_chemistry",
            name = "الكيمياء العامة والعضوية",
            category = "science-math,science-bio",
            teacherName = "د. نادية الشامي",
            lessonsCount = "28 درس ومختبر",
            progressPercent = 58,
            nextLessonTitle = "تفاعلات الاستبدال في الهيدروكربونات",
            iconName = "science",
            description = "الكيمياء العضوية والتحليل الكيميائي والاتزان الأيوني"
        ),
        Subject(
            id = "subj_biology",
            name = "الأحياء والجيولوجيا",
            category = "science-bio",
            teacherName = "د. محمد سامي",
            lessonsCount = "30 درساً شاملاً",
            progressPercent = 85,
            nextLessonTitle = "تضاعف الحمض النووي DNA وتخليق البروتين",
            iconName = "spa",
            description = "التنسيق الهرموني والتكاثر والمناعة والبيولوجيا الجزيئية"
        ),
        Subject(
            id = "subj_math",
            name = "الرياضيات البحتة والتطبيقية",
            category = "science-math",
            teacherName = "أ. أحمد سمير",
            lessonsCount = "40 درساً وتمريناً",
            progressPercent = 40,
            nextLessonTitle = "تطبيقات القيم العظمى والصغرى المحلية",
            iconName = "calculate",
            description = "التفاضل والتكامل والجبر والهندسة الفراغية والاستاتيكا"
        ),
        Subject(
            id = "subj_english",
            name = "اللغة الإنجليزية التخصصية",
            category = "languages",
            teacherName = "مستر كريم عبد العزيز",
            lessonsCount = "24 وحدة وتدريب",
            progressPercent = 65,
            nextLessonTitle = "Grammar Review: Conditionals & Inversion",
            iconName = "translate",
            description = "قواعد اللغة المتقدمة، مهارات الكتابة، وتحليل نصوص القراءة"
        )
    )

    fun getDefaultLesson(): Lesson = Lesson(
        id = "les_101",
        subjectId = "subj_physics",
        subjectTitle = "الفيزياء الكهربية • الثانوية العامة",
        chapterTitle = "الفصل الأول: التيار الكهربي وقانون أوم",
        title = "قانون أوم للدائرة المغلقة والقوة الدافعة الكهربية (VB)",
        description = "في هذا الدرس نتناول بدقة العلاقة بين القوة الدافعة الكهربية للمصدر والمقاومة الكلية للدائرة والمقاومة الداخلية للعمود (r). دراسة تفصيلية لقراءة الفولتميتر، وحالات انعدام فرق الجهد الخارجي.",
        videoDurationText = "32:45",
        currentPositionText = "14:20",
        progressPercent = 44,
        focusMinutesSpent = 18,
        isCompleted = false,
        isBookmarked = true,
        isDownloaded = false,
        formulaHeader = "قانون أوم للدائرة المغلقة",
        formulaExpression = "I = VB / (R + r)",
        formulaUnits = "أمبير (A) = فولت (V) ÷ أوم (Ω)",
        examTip = "تنبيه هام لامتحان الثانوية: عند فتح المفتاح في دائرة كهربية تحتوي على بطارية ومقاومة، فإن شدة التيار تنعدم (I=0)، وبالتالي تصبح قراءة الفولتميتر بين قطبي البطارية متساوية تماماً مع القوة الدافعة الكهربية (V = VB).",
        attachments = listOf(
            LessonAttachment(
                id = "att_1",
                title = "ملخص درس قانون أوم للدوائر المغلقة",
                description = "ملف PDF ملخص الدرس 4 صفحات",
                sizeText = "3.2 ميجابايت"
            ),
            LessonAttachment(
                id = "att_2",
                title = "ورقة تدريبات بابل شيت - 20 مسألة متدرجة",
                description = "مسائل نماذج الوزارة للأعوام السابقة",
                sizeText = "1.8 ميجابايت"
            )
        )
    )

    fun getInteractiveQuiz(): QuizQuestion = QuizQuestion(
        id = 1,
        questionNumber = 3,
        totalQuestions = 15,
        subjectTag = "فيزياء كهربائية",
        difficulty = "مستوى متقدم (نظام حديث)",
        pointsText = "+5 نقاط",
        questionText = "في الدائرة الموضحة بالشكل، إذا كانت المقاومة الداخلية للبطارية (r) غير مهملة، ماذا يحدث لقراءة الفولتميتر المتصل بين قطبي البطارية عند زيادة قيمة المقاومة المتغيرة (الريوستات S)؟",
        hintText = "استحضر العلاقة V = VB - Ir. ماذا يحدث لشدة التيار المار في الدائرة عند زيادة المقاومة الكلية؟",
        formulaRule = "V = VB - I · r",
        teacherPortraitUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuC7QzOQ2v6nCgL9e8x7k7J_9z5y4x3w2v1u0t9s8r7q6p5o4n3m2l1k0j9i8h7g6f5e4d3c2b1a",
        teacherName = "مستر حسام خليل",
        teacherTip = "عند زيادة المقاومة المتغيرة، تقل شدة التيار الكلي (I)، وبالتالي يقل المقدار المطروح (I · r) فتزداد قراءة الفولتميتر (V).",
        options = listOf(
            QuizOption("أ", "تقل قراءة الفولتميتر لأن المقاومة زادت", "خطأ، زيادة المقاومة تزيد فرق الجهد بين طرفي البطارية بسبب انخفاض التيار."),
            QuizOption("ب", "تزداد قراءة الفولتميتر لاقترابها من القوة الدافعة VB", "إجابة صحيحة وممتازة! وفقاً للعلاقة V = VB - Ir، نقصان I يقلل الهبوط في الجهد فتزداد V."),
            QuizOption("ج", "تظل ثابتة لأن القوة الدافعة الكهربية VB ثابتة", "خطأ، تظل ثابتة فقط إذا كانت المقاومة الداخلية مهملة (r = 0)."),
            QuizOption("د", "تنعدم قراءة الفولتميتر تماماً", "خطأ، تنعدم فقط في حالة انعدام القوة الدافعة.")
        ),
        correctIndex = 1
    )
}
