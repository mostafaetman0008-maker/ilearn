package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.Lesson
import com.example.data.model.LessonAttachment
import com.example.data.model.NoteItem
import com.example.data.model.PaymentReceipt
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseManager(context: Context? = null) {
    companion object {
        private const val TAG = "SupabaseManager"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val PREFS_NAME = "supabase_config"
        private const val KEY_URL = "custom_supabase_url"
        private const val KEY_ANON = "custom_supabase_anon"

        fun getDefaultUrl(): String {
            return try {
                val key = BuildConfig.SUPABASE_URL
                if (!key.isNullOrBlank() && !key.contains("xyzcompany")) key.trimEnd('/') else "https://educational-sanad.supabase.co"
            } catch (_: Throwable) {
                "https://educational-sanad.supabase.co"
            }
        }

        fun getDefaultAnonKey(): String {
            return try {
                val key = BuildConfig.SUPABASE_ANON_KEY
                if (!key.isNullOrBlank() && !key.contains("dummy")) key else "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.sanad_production_key"
            } catch (_: Throwable) {
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.sanad_production_key"
            }
        }
    }

    private val prefs = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Volatile
    var supabaseUrl: String = prefs?.getString(KEY_URL, null) ?: getDefaultUrl()
        private set

    @Volatile
    var supabaseAnonKey: String = prefs?.getString(KEY_ANON, null) ?: getDefaultAnonKey()
        private set

    fun updateCredentials(url: String, anonKey: String) {
        val cleanUrl = url.trim().trimEnd('/')
        val cleanKey = anonKey.trim()
        if (cleanUrl.isNotEmpty()) supabaseUrl = cleanUrl
        if (cleanKey.isNotEmpty()) supabaseAnonKey = cleanKey

        prefs?.edit()
            ?.putString(KEY_URL, supabaseUrl)
            ?.putString(KEY_ANON, supabaseAnonKey)
            ?.apply()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()

    @Volatile
    var currentAuthToken: String? = null

    private fun getAuthHeader(): String {
        return currentAuthToken?.let { "Bearer $it" } ?: "Bearer $supabaseAnonKey"
    }

    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code == 404 || response.code == 401 || response.code == 200) {
                if (response.code == 401) {
                    Result.failure(Exception("مفتاح API غير صالح (401 Unauthorized)"))
                } else {
                    Result.success("تم الاتصال بنجاح بخادم Supabase (كود ${response.code})")
                }
            } else {
                Result.failure(Exception("خطأ في الاتصال: كود الاستجابة ${response.code}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Test connection error: ${e.message}", e)
            Result.failure(Exception("تعذر الاتصال بـ Supabase: ${e.localizedMessage ?: "تأكد من عنوان الرابط والإنترنت"}"))
        }
    }

    // 1. REAL AUTHENTICATION: Sign Up with Email and Password
    suspend fun signUpWithEmail(name: String, email: String, pass: String): Result<User> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", pass)
                put("data", JSONObject().apply {
                    put("full_name", name.trim())
                })
            }

            val request = Request.Builder()
                .url("$supabaseUrl/auth/v1/signup")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (!response.isSuccessful) {
                val errObj = JSONObject(body)
                val msg = errObj.optString("msg", errObj.optString("error_description", "فشل إنشاء الحساب"))
                return@withContext Result.failure(Exception(msg))
            }

            val json = JSONObject(body)
            val accessToken = json.optString("access_token", "")
            if (accessToken.isNotBlank()) {
                currentAuthToken = accessToken
            }
            val userObj = json.optJSONObject("user") ?: json
            val userId = userObj.optString("id", "usr_${System.currentTimeMillis()}")
            val userName = userObj.optJSONObject("user_metadata")?.optString("full_name") ?: name.trim()

            val user = User(
                id = userId,
                name = userName.ifBlank { name.trim() },
                email = email.trim(),
                studentCode = "STD-${(1000..9999).random()}"
            )
            // Upsert profile in Supabase profiles table
            upsertProfile(user)
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Sign up error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 2. REAL AUTHENTICATION: Sign In with Email and Password
    suspend fun signInWithEmail(email: String, pass: String): Result<User> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", pass)
            }

            val request = Request.Builder()
                .url("$supabaseUrl/auth/v1/token?grant_type=password")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (!response.isSuccessful) {
                val errObj = JSONObject(body)
                val msg = errObj.optString("error_description", errObj.optString("msg", "البريد الإلكتروني أو كلمة المرور غير صحيحة"))
                return@withContext Result.failure(Exception(msg))
            }

            val json = JSONObject(body)
            val accessToken = json.optString("access_token")
            if (accessToken.isNotBlank()) {
                currentAuthToken = accessToken
            }
            val userObj = json.optJSONObject("user")
            val userId = userObj?.optString("id") ?: "usr_${System.currentTimeMillis()}"
            val userName = userObj?.optJSONObject("user_metadata")?.optString("full_name") ?: email.substringBefore("@")

            // Try to load full profile from Supabase
            val profileRes = fetchProfile(userId)
            val user = profileRes.getOrNull() ?: User(
                id = userId,
                name = userName.ifBlank { email.substringBefore("@") },
                email = email.trim(),
                studentCode = "STD-${(1000..9999).random()}"
            )

            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Sign in error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 3. REAL AUTHENTICATION: Google ID Token exchange
    suspend fun signInWithGoogleIdToken(idToken: String, email: String, displayName: String?, photoUrl: String?): Result<User> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("provider", "google")
                put("id_token", idToken)
            }

            val request = Request.Builder()
                .url("$supabaseUrl/auth/v1/token?grant_type=id_token")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = try { client.newCall(request).execute() } catch (_: Exception) { null }
            var userId = "usr_g_${System.currentTimeMillis()}"
            var userName = displayName ?: email.substringBefore("@")

            if (response != null && response.isSuccessful) {
                val body = response.body?.string() ?: "{}"
                val json = JSONObject(body)
                val accessToken = json.optString("access_token")
                if (accessToken.isNotBlank()) {
                    currentAuthToken = accessToken
                }
                val userObj = json.optJSONObject("user")
                if (userObj != null) {
                    userId = userObj.optString("id", userId)
                    val metaName = userObj.optJSONObject("user_metadata")?.optString("full_name")
                    if (!metaName.isNullOrBlank()) userName = metaName
                }
            }

            val user = User(
                id = userId,
                name = userName,
                email = email.trim(),
                avatarUrl = photoUrl ?: "",
                studentCode = "STD-${(1000..9999).random()}"
            )
            upsertProfile(user)
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Google auth error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 4. REAL DATABASE: Fetch Profile
    suspend fun fetchProfile(userId: String): Result<User> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/profiles?user_id=eq.$userId&select=*")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))

            val body = response.body?.string() ?: "[]"
            val array = JSONArray(body)
            if (array.length() == 0) return@withContext Result.failure(Exception("Profile not found"))

            val item = array.getJSONObject(0)
            val user = User(
                id = item.optString("user_id", userId),
                name = item.optString("name", ""),
                email = item.optString("email", ""),
                avatarUrl = item.optString("avatar_url", ""),
                gradeTrack = item.optString("grade_track", "الثانوية العامة • المقررات الدراسية"),
                studentCode = item.optString("student_code", "STD-${(1000..9999).random()}"),
                isSubscribed = item.optBoolean("is_subscribed", false),
                subscriptionPlan = item.optString("subscription_plan", "الخطة القياسية"),
                streakDays = item.optInt("streak_days", 0),
                focusHours = item.optInt("focus_hours", 0),
                completedLessons = item.optInt("completed_lessons", 0),
                totalLessons = item.optInt("total_lessons", 0),
                accuracyPercent = item.optInt("accuracy_percent", 0),
                examDaysLeft = item.optInt("exam_days_left", 0),
                examSubject = item.optString("exam_subject", "")
            )
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. REAL DATABASE: Upsert Profile
    suspend fun upsertProfile(user: User): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("user_id", user.id)
                put("name", user.name)
                put("email", user.email)
                put("avatar_url", user.avatarUrl)
                put("grade_track", user.gradeTrack)
                put("student_code", user.studentCode)
                put("is_subscribed", user.isSubscribed)
                put("subscription_plan", user.subscriptionPlan)
                put("streak_days", user.streakDays)
                put("focus_hours", user.focusHours)
                put("completed_lessons", user.completedLessons)
                put("total_lessons", user.totalLessons)
                put("accuracy_percent", user.accuracyPercent)
                put("exam_days_left", user.examDaysLeft)
                put("exam_subject", user.examSubject)
                put("updated_at", System.currentTimeMillis())
            }

            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/profiles?on_conflict=user_id")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .addHeader("Prefer", "resolution=merge-duplicates")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) Result.success(Unit) else Result.failure(Exception("HTTP ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. REAL DATABASE: Fetch Subjects/Courses from Supabase (Checks both 'courses' and 'subjects')
    suspend fun fetchSubjects(): Result<List<Subject>> = withContext(Dispatchers.IO) {
        try {
            // Try 'courses' table first (Coursera / LMS standard)
            var response = runCatching {
                val req = Request.Builder()
                    .url("$supabaseUrl/rest/v1/courses?select=*&order=id.asc")
                    .addHeader("apikey", supabaseAnonKey)
                    .addHeader("Authorization", getAuthHeader())
                    .get()
                    .build()
                client.newCall(req).execute()
            }.getOrNull()

            // If courses table returned 404 or empty, try 'subjects' table
            if (response == null || !response.isSuccessful) {
                val req = Request.Builder()
                    .url("$supabaseUrl/rest/v1/subjects?select=*&order=id.asc")
                    .addHeader("apikey", supabaseAnonKey)
                    .addHeader("Authorization", getAuthHeader())
                    .get()
                    .build()
                response = client.newCall(req).execute()
            }

            if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))

            val body = response.body?.string() ?: "[]"
            val array = JSONArray(body)
            val list = mutableListOf<Subject>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Subject(
                        id = obj.optString("id", "course_$i"),
                        name = obj.optString("name", obj.optString("title", "مقرر دراسي")),
                        category = obj.optString("category", "عام"),
                        teacherName = obj.optString("teacher_name", obj.optString("instructor", "المحاضر")),
                        lessonsCount = obj.optString("lessons_count", "12 درس"),
                        progressPercent = obj.optInt("progress_percent", 0),
                        nextLessonTitle = obj.optString("next_lesson_title", "متابعة الدرس القادم"),
                        iconName = obj.optString("icon_name", "menu_book"),
                        description = obj.optString("description", ""),
                        thumbnailUrl = obj.optString("thumbnail_url", obj.optString("image_url", ""))
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e(TAG, "Fetch subjects error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 7. REAL DATABASE: Fetch Lessons for a subject/course
    suspend fun fetchLessons(subjectId: String): Result<List<Lesson>> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/lessons?or=(subject_id.eq.$subjectId,course_id.eq.$subjectId)&select=*&order=order_index.asc,id.asc")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))

            val body = response.body?.string() ?: "[]"
            val array = JSONArray(body)
            val list = mutableListOf<Lesson>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Lesson(
                        id = obj.optString("id"),
                        subjectId = obj.optString("subject_id", subjectId),
                        subjectTitle = obj.optString("subject_title", ""),
                        chapterTitle = obj.optString("chapter_title", ""),
                        title = obj.optString("title"),
                        description = obj.optString("description", ""),
                        videoDurationText = obj.optString("video_duration_text", "30:00"),
                        currentPositionText = obj.optString("current_position_text", "00:00"),
                        progressPercent = obj.optInt("progress_percent", 0),
                        focusMinutesSpent = obj.optInt("focus_minutes_spent", 0),
                        isCompleted = obj.optBoolean("is_completed", false),
                        isBookmarked = obj.optBoolean("is_bookmarked", false),
                        formulaHeader = obj.optString("formula_header", "الملخص القانوني"),
                        formulaExpression = obj.optString("formula_expression", ""),
                        formulaUnits = obj.optString("formula_units", ""),
                        examTip = obj.optString("exam_tip", "")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 8. REAL DATABASE: Fetch Notes / Summaries / Materials
    suspend fun fetchNotes(): Result<List<NoteItem>> = withContext(Dispatchers.IO) {
        try {
            var response = runCatching {
                val req = Request.Builder()
                    .url("$supabaseUrl/rest/v1/notes?select=*&order=id.asc")
                    .addHeader("apikey", supabaseAnonKey)
                    .addHeader("Authorization", getAuthHeader())
                    .get()
                    .build()
                client.newCall(req).execute()
            }.getOrNull()

            if (response == null || !response.isSuccessful) {
                val req = Request.Builder()
                    .url("$supabaseUrl/rest/v1/materials?select=*&order=id.asc")
                    .addHeader("apikey", supabaseAnonKey)
                    .addHeader("Authorization", getAuthHeader())
                    .get()
                    .build()
                response = client.newCall(req).execute()
            }

            if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))

            val body = response.body?.string() ?: "[]"
            val array = JSONArray(body)
            val list = mutableListOf<NoteItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    NoteItem(
                        id = obj.optLong("id", i.toLong() + 1),
                        title = obj.optString("title"),
                        author = obj.optString("author", obj.optString("instructor", "")),
                        subject = obj.optString("subject", obj.optString("course", "")),
                        pagesCount = obj.optInt("pages_count", 10),
                        sizeMb = obj.optDouble("size_mb", 3.0),
                        progressPercent = obj.optInt("progress_percent", 0),
                        isOfflineReady = obj.optBoolean("is_offline_ready", true),
                        isBookmarked = obj.optBoolean("is_bookmarked", false),
                        tag = obj.optString("tag", "مذكرة معتمدة"),
                        previewImageUrl = obj.optString("preview_image_url", obj.optString("thumbnail_url", ""))
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 9. REAL DATABASE: Fetch Tasks for User
    suspend fun fetchTasks(userId: String): Result<List<StudyTask>> = withContext(Dispatchers.IO) {
        try {
            val url = if (userId.isNotBlank()) {
                "$supabaseUrl/rest/v1/tasks?user_id=eq.$userId&select=*&order=id.asc"
            } else {
                "$supabaseUrl/rest/v1/tasks?select=*&order=id.asc"
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))

            val body = response.body?.string() ?: "[]"
            val array = JSONArray(body)
            val list = mutableListOf<StudyTask>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    StudyTask(
                        id = obj.optLong("id", i.toLong() + 1),
                        title = obj.optString("title"),
                        subtitle = obj.optString("subtitle", ""),
                        isCompleted = obj.optBoolean("is_completed", false)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 10. REAL DATABASE: Insert Task to Supabase
    suspend fun createTask(userId: String, title: String, subtitle: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("user_id", userId.ifBlank { "anonymous" })
                put("title", title)
                put("subtitle", subtitle)
                put("is_completed", false)
                put("created_at", System.currentTimeMillis())
            }

            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/tasks")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) Result.success(Unit) else Result.failure(Exception("HTTP ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 11. REAL DATABASE: Update Task Completion in Supabase
    suspend fun updateTaskStatus(taskId: Long, isCompleted: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("is_completed", isCompleted)
            }

            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/tasks?id=eq.$taskId")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .patch(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) Result.success(Unit) else Result.failure(Exception("HTTP ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. REAL DATABASE: Submit Payment Request to Supabase
    suspend fun submitPaymentRequest(userId: String, receipt: PaymentReceipt): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("user_id", userId.ifBlank { "anonymous" })
                put("txn_code", receipt.txnCode)
                put("amount_egp", receipt.amountEgp)
                put("payment_method", receipt.paymentMethod)
                put("plan_name", receipt.planName)
                put("sender_phone", receipt.senderPhone)
                put("status", "pending_verification")
                put("created_at", System.currentTimeMillis())
            }

            val request = Request.Builder()
                .url("$supabaseUrl/rest/v1/payment_requests")
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", getAuthHeader())
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) Result.success(Unit) else Result.failure(Exception("HTTP ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Helper returning SQL script to create tables in Supabase for matching Web Dashboard
    fun getDatabaseSqlSchema(): String {
        return """
            -- جدول المساقات والمناهج الدراسية (Courses / Subjects)
            CREATE TABLE IF NOT EXISTS public.courses (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT,
                teacher_name TEXT,
                lessons_count TEXT,
                progress_percent INTEGER DEFAULT 0,
                next_lesson_title TEXT,
                icon_name TEXT,
                description TEXT,
                thumbnail_url TEXT,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
            );

            -- جدول الدروس والمحاضرات (Lessons)
            CREATE TABLE IF NOT EXISTS public.lessons (
                id TEXT PRIMARY KEY,
                subject_id TEXT,
                course_id TEXT,
                subject_title TEXT,
                chapter_title TEXT,
                title TEXT NOT NULL,
                description TEXT,
                video_url TEXT,
                video_duration_text TEXT,
                current_position_text TEXT,
                progress_percent INTEGER DEFAULT 0,
                focus_minutes_spent INTEGER DEFAULT 0,
                is_completed BOOLEAN DEFAULT false,
                is_bookmarked BOOLEAN DEFAULT false,
                formula_header TEXT,
                formula_expression TEXT,
                formula_units TEXT,
                exam_tip TEXT,
                order_index INTEGER DEFAULT 0
            );

            -- جدول مهام وتكليفات الطلاب (Tasks)
            CREATE TABLE IF NOT EXISTS public.tasks (
                id BIGSERIAL PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT NOT NULL,
                subtitle TEXT,
                is_completed BOOLEAN DEFAULT false,
                created_at BIGINT
            );

            -- جدول المذكرات والمصادر والمكتبة (Notes / Materials)
            CREATE TABLE IF NOT EXISTS public.notes (
                id BIGSERIAL PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT,
                subject TEXT,
                pages_count INTEGER DEFAULT 0,
                size_mb NUMERIC DEFAULT 0,
                progress_percent INTEGER DEFAULT 0,
                is_offline_ready BOOLEAN DEFAULT true,
                is_bookmarked BOOLEAN DEFAULT false,
                tag TEXT,
                preview_image_url TEXT,
                download_url TEXT
            );

            -- جدول الملفات الشخصية للطلاب (Profiles)
            CREATE TABLE IF NOT EXISTS public.profiles (
                user_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT,
                avatar_url TEXT,
                grade_track TEXT,
                student_code TEXT,
                is_subscribed BOOLEAN DEFAULT false,
                subscription_plan TEXT DEFAULT 'الخطة القياسية',
                streak_days INTEGER DEFAULT 0,
                focus_hours INTEGER DEFAULT 0,
                completed_lessons INTEGER DEFAULT 0,
                total_lessons INTEGER DEFAULT 0,
                accuracy_percent INTEGER DEFAULT 0,
                exam_days_left INTEGER DEFAULT 0,
                exam_subject TEXT,
                updated_at BIGINT
            );

            -- جدول طلبات الاشتراك والدفع (Payment Requests)
            CREATE TABLE IF NOT EXISTS public.payment_requests (
                id BIGSERIAL PRIMARY KEY,
                user_id TEXT NOT NULL,
                txn_code TEXT,
                amount_egp INTEGER,
                payment_method TEXT,
                plan_name TEXT,
                sender_phone TEXT,
                status TEXT DEFAULT 'pending',
                created_at BIGINT
            );

            -- سياسات الوصول (RLS) للسماح بقراءة وكتابة البيانات المباشرة
            ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
            ALTER TABLE public.payment_requests ENABLE ROW LEVEL SECURITY;

            CREATE POLICY "Allow public read courses" ON public.courses FOR SELECT USING (true);
            CREATE POLICY "Allow public write courses" ON public.courses FOR ALL USING (true);

            CREATE POLICY "Allow public read lessons" ON public.lessons FOR SELECT USING (true);
            CREATE POLICY "Allow public write lessons" ON public.lessons FOR ALL USING (true);

            CREATE POLICY "Allow public read tasks" ON public.tasks FOR SELECT USING (true);
            CREATE POLICY "Allow public write tasks" ON public.tasks FOR ALL USING (true);

            CREATE POLICY "Allow public read notes" ON public.notes FOR SELECT USING (true);
            CREATE POLICY "Allow public write notes" ON public.notes FOR ALL USING (true);

            CREATE POLICY "Allow public read profiles" ON public.profiles FOR SELECT USING (true);
            CREATE POLICY "Allow public write profiles" ON public.profiles FOR ALL USING (true);

            CREATE POLICY "Allow public read payments" ON public.payment_requests FOR SELECT USING (true);
            CREATE POLICY "Allow public write payments" ON public.payment_requests FOR ALL USING (true);
        """.trimIndent()
    }
}
