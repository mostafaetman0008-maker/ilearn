package com.example.data.model

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val avatarUrl: String = "",
    val gradeTrack: String = "الثانوية العامة • المقررات الدراسية",
    val studentCode: String = "",
    val isSubscribed: Boolean = false,
    val subscriptionPlan: String = "الخطة القياسية",
    val streakDays: Int = 0,
    val focusHours: Int = 0,
    val completedLessons: Int = 0,
    val totalLessons: Int = 0,
    val accuracyPercent: Int = 0,
    val examDaysLeft: Int = 0,
    val examSubject: String = ""
)

data class Subject(
    val id: String,
    val name: String,
    val category: String, // science-bio, science-math, literary, languages, general
    val teacherName: String,
    val lessonsCount: String,
    val progressPercent: Int,
    val nextLessonTitle: String,
    val iconName: String,
    val description: String = "",
    val thumbnailUrl: String = ""
)

data class LessonAttachment(
    val id: String,
    val title: String,
    val description: String,
    val sizeText: String,
    val isPdf: Boolean = true
)

data class Lesson(
    val id: String,
    val subjectId: String,
    val subjectTitle: String,
    val chapterTitle: String,
    val title: String,
    val description: String,
    val videoDurationText: String = "32:45",
    val currentPositionText: String = "14:20",
    val progressPercent: Int = 0,
    val focusMinutesSpent: Int = 0,
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val isDownloaded: Boolean = false,
    val formulaHeader: String = "شدة التيار الكهربي الكلي في الدائرة المغلقة",
    val formulaExpression: String = "I = VB / (R + r)",
    val formulaUnits: String = "أمبير (A) = فولت (V) ÷ أوم (Ω)",
    val examTip: String = "قراءة الفولتميتر بين قطبي البطارية: V = VB - Ir. لاحظ أن العلاقة بين فرق الجهد (V) وشدة التيار (I) هي علاقة تناقصية، وميل الخط المستقيم يمثل السالب للمقاومة الداخلية (-r)، والجزء المقطوع من محور الصادات يساوي VB.",
    val attachments: List<LessonAttachment> = listOf(
        LessonAttachment(
            id = "att_1",
            title = "ملخص درس قانون أوم للدوائر المغلقة",
            description = "ملف PDF ملخص الدرس 4 صفحات",
            sizeText = "3.2 ميجابايت"
        )
    )
)

data class StudyTask(
    val id: Long = 0,
    val title: String,
    val subtitle: String,
    val isCompleted: Boolean = false
)

data class NoteItem(
    val id: Long = 0,
    val title: String,
    val author: String,
    val subject: String,
    val pagesCount: Int,
    val sizeMb: Double,
    val progressPercent: Int,
    val isOfflineReady: Boolean,
    val isBookmarked: Boolean,
    val tag: String,
    val previewImageUrl: String = ""
)

data class QuizOption(
    val letter: String,
    val text: String,
    val explanation: String = ""
)

data class QuizQuestion(
    val id: Int,
    val questionNumber: Int,
    val totalQuestions: Int,
    val subjectTag: String,
    val difficulty: String,
    val pointsText: String,
    val questionText: String,
    val hintText: String,
    val formulaRule: String,
    val teacherPortraitUrl: String,
    val teacherName: String,
    val teacherTip: String,
    val options: List<QuizOption>,
    val correctIndex: Int
)

enum class BillingPeriod(val title: String, val badge: String) {
    MONTHLY("شهري", "الأكثر طلباً"),
    TERM("ترم كامل", "خصم 20%"),
    YEAR("السنة كاملة", "⭐ الأكثر توفيراً")
}

data class PlanOption(
    val id: String,
    val name: String,
    val subtitle: String,
    val priceEgp: Int,
    val originalPriceEgp: Int,
    val period: BillingPeriod,
    val features: List<String>,
    val isFeatured: Boolean = false
)

data class PaymentReceipt(
    val txnCode: String = "",
    val timestamp: String = "",
    val paymentMethod: String = "فودافون كاش / إنستاباي",
    val planName: String = "باقة المتفوق – الترم كامل",
    val senderPhone: String = "",
    val amountEgp: Int = 350,
    val isVerified: Boolean = true
)
