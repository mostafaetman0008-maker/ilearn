package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.BillingPeriod
import com.example.ui.theme.AmberFixed
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.AmberWarmContainer
import com.example.ui.theme.DeepTeal
import com.example.ui.theme.DeepTealContainer
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.OutlineVariant
import com.example.ui.theme.SageFixed
import com.example.ui.theme.SageGreen
import com.example.ui.theme.SageGreenContainer
import com.example.ui.theme.SurfaceContainer
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.SurfacePaper

@Composable
fun SubscriptionScreen(
    billingPeriod: BillingPeriod,
    selectedPlanId: String,
    couponDiscount: Int,
    senderPhone: String,
    transactionRef: String,
    receiptFileName: String?,
    onBack: () -> Unit,
    onSelectBillingPeriod: (BillingPeriod) -> Unit,
    onSelectPlan: (String) -> Unit,
    onSetSenderPhone: (String) -> Unit,
    onSetTransactionRef: (String) -> Unit,
    onApplyCoupon: (String) -> Unit,
    onSimulateUpload: () -> Unit,
    onCopyText: (String, String) -> Unit,
    onConfirmPayment: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var couponInput by remember { mutableStateOf("الأستاذ حسام") }
    var expandedPaymentMethod by remember { mutableStateOf("vodafone") }

    val basePrice = if (selectedPlanId == "term") 450 else 180
    val planDiscount = if (selectedPlanId == "term") 100 else 60
    val totalAmount = (basePrice - planDiscount - couponDiscount).coerceAtLeast(50)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfacePaper)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 96.dp)
        ) {
            // Top App Bar
            Surface(
                color = SurfacePaper.copy(alpha = 0.95f),
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .height(56.dp)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SurfaceContainerLow)
                                .testTag("sub_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = DeepTeal,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Text(
                            text = "Checkout And Payment Confirmation",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepTeal
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(SageGreenContainer.copy(alpha = 0.6f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = SageGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Text("دفع آمن ومشفّر", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SageGreen)
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Trust Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SageGreenContainer.copy(alpha = 0.5f))
                        .padding(vertical = 10.dp, horizontal = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = SageGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "دفع آمن ومحمي 100% • تفعيل فوري ومتابعة خلال 5 دقائق",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SageGreen
                        )
                    }
                }

                // Billing Cycle Period Selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceContainerHigh)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    BillingPeriod.entries.forEach { period ->
                        val isSelected = billingPeriod == period
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) SurfaceContainerLowest else Color.Transparent)
                                .clickable { onSelectBillingPeriod(period) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = period.title,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) DeepTeal else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = period.badge,
                                    fontSize = 9.sp,
                                    color = if (isSelected) SageGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // 2. Order Summary Card (ملخص الاشتراك)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(1.dp, RoundedCornerShape(16.dp))
                        .testTag("sub_order_summary_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(SageGreenContainer.copy(alpha = 0.6f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text("الثانوية العامة • علمي علوم", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("باقة المتفوق – الترم كامل 2025", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                Text("منصة سَنَد التعليمية • دمج المناهج والمراجعات الذكية", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SurfaceContainerLow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = DeepTeal,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Feature Inclusions List
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SurfaceContainerLow)
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            InclusionItem("بنك أسئلة البابل شيت الشامل ونماذج الامتحانات")
                            InclusionItem("فيديوهات شرح مركزة وعالية الجودة بدون تشتيت")
                            InclusionItem("جميع المذكرات والخرائط الذهنية بصيغة PDF جاهزة للطباعة")
                            InclusionItem("قنوات تفاعلية للدعم المباشر وإجابة الاستفسارات")
                        }

                        // Price breakdown
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("السعر الأصلي للباقة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("$basePrice ج.م", fontSize = 12.sp, textDecoration = TextDecoration.LineThrough, color = OutlineVariant)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("كوبون خصم (الأستاذ حسام)", fontSize = 12.sp, color = SageGreen, fontWeight = FontWeight.SemiBold)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(SageGreenContainer.copy(alpha = 0.7f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("-100 ج.م", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                }
                            }

                            HorizontalDivider(color = SurfaceContainerHigh, modifier = Modifier.padding(vertical = 4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text("المبلغ الإجمالي المستحق", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("شامل كامل الصلاحيات والامتحانات", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = DeepTeal)
                                }
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text("$totalAmount", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ج.م", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                }
                            }
                        }
                    }
                }

                // 3. Selected Payment Method Details Card (طريقة التحويل المعتمدة)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(1.dp, RoundedCornerShape(16.dp))
                        .testTag("sub_payment_methods_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CreditCard,
                                    contentDescription = null,
                                    tint = DeepTeal,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text("طريقة التحويل المعتمدة", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AmberFixed)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text("يدوي وسريع", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AmberWarm)
                            }
                        }

                        // Switcher buttons (Vodafone Cash vs InstaPay)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceContainerLow)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Button(
                                onClick = { expandedPaymentMethod = "vodafone" },
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (expandedPaymentMethod == "vodafone") SurfaceContainerLowest else Color.Transparent,
                                    contentColor = DeepTeal
                                )
                            ) {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("محافظ المحمول (كاش)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = { expandedPaymentMethod = "instapay" },
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (expandedPaymentMethod == "instapay") SurfaceContainerLowest else Color.Transparent,
                                    contentColor = DeepTeal
                                )
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تطبيق إنستاباي InstaPay", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        // Wallet Number Card
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SurfaceContainerLow)
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (expandedPaymentMethod == "vodafone") "رقم محفظة الاستقبال (فودافون كاش / أورنج / وي)" else "عنوان إنستاباي اللحظي (IPA)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SurfaceContainerLowest)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (expandedPaymentMethod == "vodafone") "01023456789" else "sanad.edu@instapay",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DeepTeal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text("سَنَد التعليمية - حساب رسمي", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Button(
                                    onClick = {
                                        val text = if (expandedPaymentMethod == "vodafone") "01023456789" else "sanad.edu@instapay"
                                        onCopyText(text, "رقم التحويل")
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepTeal),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ", fontSize = 11.sp)
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = SageGreen, modifier = Modifier.size(15.dp))
                                Text(
                                    text = "يرجى تحويل مبلغ $totalAmount ج.م بالضبط لضمان سرعة الربط التلقائي.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // 4. Payment Verification & Receipt Submission
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(1.dp, RoundedCornerShape(16.dp))
                        .testTag("sub_receipt_submission_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("تأكيد التحويل وإرفاق الإشعار", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)

                        // Sender phone
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("رقم الهاتف / المحفظة الذي تم التحويل منه *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = senderPhone,
                                onValueChange = { onSetSenderPhone(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sub_sender_phone_input"),
                                placeholder = { Text("مثال: 01012345678", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = OutlineVariant)
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = SurfaceContainerLow,
                                    unfocusedContainerColor = SurfaceContainerLow,
                                    focusedBorderColor = DeepTeal,
                                    unfocusedBorderColor = Color.Transparent
                                )
                            )
                            Text("سنستخدم هذا الرقم لمطابقة رسالة الاستلام فوراً.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        // Transaction Ref
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("كود العملية أو الرقم المرجعي (اختياري)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            OutlinedTextField(
                                value = transactionRef,
                                onValueChange = { onSetTransactionRef(it) },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("مثال: 948201481", fontSize = 12.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = SurfaceContainerLow,
                                    unfocusedContainerColor = SurfaceContainerLow,
                                    focusedBorderColor = DeepTeal,
                                    unfocusedBorderColor = Color.Transparent
                                )
                            )
                        }

                        // Receipt Dropzone & Active State
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("إشعار أو سكرين شوت العملية *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                            if (receiptFileName == null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(SurfaceContainerLow)
                                        .clickable { onSimulateUpload() }
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(CircleShape)
                                                .background(SageGreenContainer.copy(alpha = 0.7f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = SageGreen)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("اضغط هنا لإرفاق إيصال التحويل", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                        Text("يدعم صور JPG، PNG أو مستند PDF (بحد أقصى 5 ميجا)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(SageGreenContainer.copy(alpha = 0.5f))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SageGreen)
                                        Column {
                                            Text(receiptFileName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                            Text("240 كيلوبايت • تم التحميل بنجاح", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    Text(
                                        text = "تغيير",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SageGreen,
                                        modifier = Modifier.clickable { onSimulateUpload() }
                                    )
                                }
                            }
                        }
                    }
                }

                // 5. Reassurance & Guarantee
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLow),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceContainerLowest),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = SageGreen, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text("ضمان الرضا واسترجاع مرن لمدة 7 أيام", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                Text(
                                    text = "لو حسيت إن المحتوى مش مناسب لطريقتك في المذاكرة، تقدر تسترد المبلغ كاملاً بكل هدوء وبدون أي تعقيد.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        HorizontalDivider(color = SurfaceContainerHigh)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = SageGreen, modifier = Modifier.size(16.dp))
                                Text("واجهتك خطوة مش واضحة؟", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/201023456789"))
                                    context.startActivity(intent)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SurfaceContainerLowest),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("دعم واتساب الفوري", fontSize = 11.sp, color = SageGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Sticky Bottom Confirm Button
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            color = SurfacePaper.copy(alpha = 0.95f),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = onConfirmPayment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("sub_confirm_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepTeal)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("تأكيد الدفع وتفعيل حسابي الآن", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = SageGreen, modifier = Modifier.size(14.dp))
                    Text("بمجرد الضغط على تأكيد، يُراجع النظام الإشعار ويُفتح لك جدول الحصص فوراً.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun InclusionItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SageGreen, modifier = Modifier.size(16.dp))
        Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}
