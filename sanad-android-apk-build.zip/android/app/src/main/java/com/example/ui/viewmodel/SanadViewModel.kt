package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SanadDatabase
import com.example.data.model.BillingPeriod
import com.example.data.model.Lesson
import com.example.data.model.NoteItem
import com.example.data.model.PaymentReceipt
import com.example.data.model.QuizQuestion
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.User
import com.example.data.repository.SanadRepository
import com.example.ui.navigation.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SanadViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanadDatabase.getDatabase(application)
    val repository = SanadRepository(database, application)

    private val _currentScreen = MutableStateFlow(Screen.LOGIN)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf(Screen.LOGIN)

    private val _currentUser = MutableStateFlow(
        User(
            id = "usr_guest",
            name = "طالب المنصة",
            email = "",
            gradeTrack = "الثانوية العامة • المقررات الدراسية",
            studentCode = "STD-7391"
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    val tasks: StateFlow<List<StudyTask>> = repository.allTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notes: StateFlow<List<NoteItem>> = repository.allNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val subjects: StateFlow<List<Subject>> = repository.subjects

    private val _activeLesson = MutableStateFlow(repository.getDefaultLesson())
    val activeLesson: StateFlow<Lesson> = _activeLesson.asStateFlow()

    // Video player state
    private val _isVideoPlaying = MutableStateFlow(false)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _playbackSpeed = MutableStateFlow("1.25x")
    val playbackSpeed: StateFlow<String> = _playbackSpeed.asStateFlow()

    // Interactive Quiz State
    val quizQuestion: QuizQuestion = repository.getInteractiveQuiz()
    private val _selectedQuizOption = MutableStateFlow<Int?>(1)
    val selectedQuizOption: StateFlow<Int?> = _selectedQuizOption.asStateFlow()

    private val _isQuizHintVisible = MutableStateFlow(false)
    val isQuizHintVisible: StateFlow<Boolean> = _isQuizHintVisible.asStateFlow()

    private val _is5050Active = MutableStateFlow(false)
    val is5050Active: StateFlow<Boolean> = _is5050Active.asStateFlow()

    private val _quizSecondsLeft = MutableStateFlow(105)
    val quizSecondsLeft: StateFlow<Int> = _quizSecondsLeft.asStateFlow()

    // Subscription & Payment State
    private val _billingPeriod = MutableStateFlow(BillingPeriod.TERM)
    val billingPeriod: StateFlow<BillingPeriod> = _billingPeriod.asStateFlow()

    private val _selectedPlanId = MutableStateFlow("term")
    val selectedPlanId: StateFlow<String> = _selectedPlanId.asStateFlow()

    private val _couponCode = MutableStateFlow("")
    val couponCode: StateFlow<String> = _couponCode.asStateFlow()

    private val _couponDiscount = MutableStateFlow(0)
    val couponDiscount: StateFlow<Int> = _couponDiscount.asStateFlow()

    private val _senderPhone = MutableStateFlow("")
    val senderPhone: StateFlow<String> = _senderPhone.asStateFlow()

    private val _transactionRef = MutableStateFlow("")
    val transactionRef: StateFlow<String> = _transactionRef.asStateFlow()

    private val _receiptFileName = MutableStateFlow<String?>(null)
    val receiptFileName: StateFlow<String?> = _receiptFileName.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow("لم تتم بعد")
    val lastSyncTimestamp: StateFlow<String> = _lastSyncTimestamp.asStateFlow()

    private val _isComfortMode = MutableStateFlow(false)
    val isComfortMode: StateFlow<Boolean> = _isComfortMode.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
            startQuizTimer()
            syncFromSupabase()
        }
    }

    private fun startQuizTimer() {
        viewModelScope.launch {
            while (_quizSecondsLeft.value > 0) {
                delay(1000)
                _quizSecondsLeft.value -= 1
            }
        }
    }

    fun syncFromSupabase() {
        viewModelScope.launch {
            _isSyncing.value = true
            val success = repository.syncWithSupabase(_currentUser.value.id)
            _isSyncing.value = false
            _lastSyncTimestamp.value = "الآن"
            if (success) {
                showToast("تمت المزامنة المباشرة مع قاعدة البيانات بنجاح 🔄")
            }
        }
    }

    fun updateSupabaseCredentials(url: String, anonKey: String) {
        repository.supabaseManager.updateCredentials(url, anonKey)
        showToast("تم تحديث بيانات الاتصال بـ Supabase")
        syncFromSupabase()
    }

    fun testSupabaseConnection(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.supabaseManager.testConnection()
            res.onSuccess { msg ->
                onResult(true, msg)
            }.onFailure { err ->
                onResult(false, err.message ?: "فشل الاتصال بقاعدة البيانات")
            }
        }
    }

    fun getDatabaseSqlSchema(): String {
        return repository.supabaseManager.getDatabaseSqlSchema()
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.size > 1) {
            screenBackStack.removeAt(screenBackStack.size - 1)
            _currentScreen.value = screenBackStack.last()
            return true
        }
        return false
    }

    fun showToast(msg: String) {
        viewModelScope.launch {
            _toastMessage.value = msg
            delay(2400)
            if (_toastMessage.value == msg) {
                _toastMessage.value = null
            }
        }
    }

    fun toggleTask(id: Long, completed: Boolean) {
        viewModelScope.launch {
            repository.toggleTask(_currentUser.value.id, id, completed)
            showToast(if (completed) "تم إنجاز المهمة وحفظها في قاعدة البيانات" else "تم إلغاء تحديد المهمة")
        }
    }

    fun addNewTask(title: String, subtitle: String) {
        viewModelScope.launch {
            repository.addNewTask(_currentUser.value.id, title, subtitle)
            showToast("تمت إضافة المهمة وحفظها في قاعدة البيانات")
        }
    }

    fun toggleBookmark(id: Long, current: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(id, current)
            showToast(if (!current) "تم حفظ المذكرة للمفضلة" else "تمت إزالة المذكرة من المفضلة")
        }
    }

    fun toggleOfflineDownload(id: Long, current: Boolean) {
        viewModelScope.launch {
            repository.toggleOfflineReady(id, current)
            showToast(if (!current) "تم حفظ المذكرة للاستخدام أوفلاين" else "تمت إزالة التحميل")
        }
    }

    fun toggleVideoPlay() {
        _isVideoPlaying.value = !_isVideoPlaying.value
    }

    fun cyclePlaybackSpeed() {
        val speeds = listOf("1.0x", "1.25x", "1.5x", "2.0x")
        val currentIndex = speeds.indexOf(_playbackSpeed.value)
        val next = speeds[(currentIndex + 1) % speeds.size]
        _playbackSpeed.value = next
        showToast("سرعة التشغيل: $next")
    }

    fun markLessonComplete() {
        _activeLesson.value = _activeLesson.value.copy(
            isCompleted = true,
            progressPercent = 100
        )
        showToast("تم تسجيل إكمال الدرس في سجل دراستك (+50 نقطة)")
        viewModelScope.launch {
            repository.supabaseManager.upsertProfile(
                _currentUser.value.copy(
                    completedLessons = _currentUser.value.completedLessons + 1
                )
            )
        }
    }

    fun toggleLessonBookmark() {
        val next = !_activeLesson.value.isBookmarked
        _activeLesson.value = _activeLesson.value.copy(isBookmarked = next)
        showToast(if (next) "تم حفظ الدرس للمفضلة" else "تمت إزالة الدرس من المفضلة")
    }

    fun selectQuizOption(index: Int) {
        _selectedQuizOption.value = index
    }

    fun toggleQuizHint() {
        _isQuizHintVisible.value = !_isQuizHintVisible.value
    }

    fun use5050Lifeline() {
        _is5050Active.value = true
        showToast("تم استبعاد الإجابتين (أ) و (د)")
    }

    fun confirmQuizAnswer() {
        if (_selectedQuizOption.value == quizQuestion.correctIndex) {
            showToast("إجابة صحيحة! تم تسجيل النتيجة في سجل تقدمك")
        } else {
            showToast("تم حفظ الإجابة، يمكنك مراجعة الشرح لاحقاً")
        }
    }

    fun setBillingPeriod(period: BillingPeriod) {
        _billingPeriod.value = period
    }

    fun selectPlan(planId: String) {
        _selectedPlanId.value = planId
    }

    fun setSenderPhone(phone: String) {
        _senderPhone.value = phone
    }

    fun setTransactionRef(ref: String) {
        _transactionRef.value = ref
    }

    fun setReceiptFile(name: String?) {
        _receiptFileName.value = name
        if (name != null) {
            showToast("تم إرفاق إشعار التحويل بنجاح")
        } else {
            showToast("تم حذف الإشعار")
        }
    }

    fun applyCoupon(code: String) {
        _couponCode.value = code
        if (code.isNotBlank()) {
            _couponDiscount.value = 50
            showToast("تم تطبيق كود الخصم: -50 ج.م إضافي")
        } else {
            showToast("يرجى إدخال كود الخصم أولاً")
        }
    }

    fun confirmPayment() {
        if (_senderPhone.value.isBlank() || _senderPhone.value.length < 10) {
            showToast("يرجى كتابة رقم الهاتف المُحوّل منه")
            return
        }
        showToast("جاري إرسال إشعار التحويل إلى قاعدة البيانات...")
        viewModelScope.launch {
            val receipt = PaymentReceipt(
                txnCode = _transactionRef.value.ifBlank { "TXN-${System.currentTimeMillis()}" },
                amountEgp = 350 - _couponDiscount.value,
                paymentMethod = "فودافون كاش / إنستاباي",
                planName = "باقة المتفوق – الترم كامل",
                senderPhone = _senderPhone.value
            )
            repository.submitPaymentRequest(_currentUser.value.id, receipt)
            _currentUser.value = _currentUser.value.copy(
                isSubscribed = true,
                subscriptionPlan = "باقة المتفوق – قيد المراجعة الفورية"
            )
            repository.supabaseManager.upsertProfile(_currentUser.value)
            navigateTo(Screen.CONFIRMATION)
        }
    }

    fun toggleComfortMode() {
        _isComfortMode.value = !_isComfortMode.value
        showToast(if (_isComfortMode.value) "تم تفعيل المظهر المريح للعين" else "تم إيقاف المظهر المريح")
    }

    // REAL AUTHENTICATION: Email Sign In
    fun loginWithEmail(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            showToast("يرجى إدخال البريد الإلكتروني وكلمة المرور")
            return
        }
        viewModelScope.launch {
            showToast("جاري التحقق من الحساب عبر قاعدة البيانات...")
            val result = repository.supabaseManager.signInWithEmail(email, pass)
            result.onSuccess { user ->
                _currentUser.value = user
                showToast("تم تسجيل الدخول بنجاح: ${user.name.ifBlank { user.email }}")
                syncFromSupabase()
                _currentScreen.value = Screen.DASHBOARD
            }.onFailure { err ->
                showToast(err.message ?: "فشل تسجيل الدخول، تأكد من صحة البيانات")
            }
        }
    }

    // REAL AUTHENTICATION: Email Sign Up
    fun signUpWithEmail(name: String, email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            showToast("يرجى إدخال البريد الإلكتروني وكلمة المرور")
            return
        }
        viewModelScope.launch {
            showToast("جاري إنشاء الحساب في قاعدة البيانات...")
            val result = repository.supabaseManager.signUpWithEmail(name, email, pass)
            result.onSuccess { user ->
                _currentUser.value = user
                showToast("تم إنشاء الحساب بنجاح! مرحباً بك يا ${user.name}")
                syncFromSupabase()
                _currentScreen.value = Screen.DASHBOARD
            }.onFailure { err ->
                showToast(err.message ?: "فشل إنشاء الحساب، يرجى المحاولة مرة أخرى")
            }
        }
    }

    // REAL AUTHENTICATION: Google Sign In
    fun loginWithGoogle(
        idToken: String = "google_id_token",
        email: String = "student@gmail.com",
        name: String = "طالب المنصة",
        photoUrl: String? = null
    ) {
        viewModelScope.launch {
            showToast("جاري المتابعة بحساب Google عبر Supabase...")
            val result = repository.supabaseManager.signInWithGoogleIdToken(
                idToken = idToken,
                email = email,
                displayName = name,
                photoUrl = photoUrl
            )
            result.onSuccess { user ->
                _currentUser.value = user
                showToast("تم تسجيل الدخول بحساب Google بنجاح")
                syncFromSupabase()
                _currentScreen.value = Screen.DASHBOARD
            }.onFailure { err ->
                showToast(err.message ?: "فشل تسجيل الدخول بحساب Google")
            }
        }
    }

    fun logout() {
        repository.supabaseManager.currentAuthToken = null
        _currentUser.value = User(
            id = "usr_guest",
            name = "طالب المنصة",
            email = "",
            gradeTrack = "الثانوية العامة • المقررات الدراسية",
            studentCode = "STD-7391"
        )
        _currentScreen.value = Screen.LOGIN
        showToast("تم تسجيل الخروج بنجاح")
    }
}
